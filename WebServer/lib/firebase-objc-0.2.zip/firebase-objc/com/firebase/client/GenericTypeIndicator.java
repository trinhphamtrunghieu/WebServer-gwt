package com.firebase.client;

public class GenericTypeIndicator<T> {

}
